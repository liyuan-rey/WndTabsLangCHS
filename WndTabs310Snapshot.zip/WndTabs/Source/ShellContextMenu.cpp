/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomonovich, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/


// ShellContextMenu.cpp : implementation file
//
// Handles the creation of the shell context menu, including the "Send To..."
// sub-menu.  
// Personal note: I think that MS should have made the code to populate and
// handle the "Send To..." sub-menu a part of the shell context menu code.  
// But they didn't, so now we're forced to write a whole lot of spaghetti COM 
// code to do what should have been a trivial part of the OS.  See the code 
// below and judge for yourself.
//
// Additions/Fixes by Philip Oldaker (philip@masmex.com)

#include "stdafx.h"
#include "ShellContextMenu.h"
#include "PIDL.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// these are the menu id's for the "Send To" and "Open With" items
#define IDM_SENDTOID           20028
#define IDM_OPENWITHID_MIN     20099

// OpenWith menu registry keys
static LPCTSTR szAppKey = _T("Applications");
static LPCTSTR szOpenWithListKey = _T("OpenWithList");
static LPCTSTR szShellKey = _T("shell");
static LPCTSTR szCommandKey = _T("command");
static LPCTSTR szFileExtKey = _T("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts");
// OpenWith menu entries
static LPCTSTR szMRUListEntry = _T("MRUList");
static LPCTSTR szDisplayNameEntry = _T("FriendlyCache");


static class CShCMInitializer
{
public:
    CShCMInitializer();
    ~CShCMInitializer();

    static LPSHELLFOLDER   m_sfDesktop;
    static LPSHELLFOLDER   m_sfSendTo;
    static CImageList *    m_pShellImageList;
    static CPIDL           m_pidlSendTo;
} stat_data;

LPSHELLFOLDER CShCMInitializer::m_sfDesktop       = NULL;
LPSHELLFOLDER CShCMInitializer::m_sfSendTo        = NULL;
CImageList *  CShCMInitializer::m_pShellImageList = NULL;
CPIDL         CShCMInitializer::m_pidlSendTo;

CShCMInitializer::CShCMInitializer()
{
    HRESULT     hr;
    SHFILEINFO  sfi;

    SHGetDesktopFolder(&m_sfDesktop);

    hr = SHGetSpecialFolderLocation(NULL, CSIDL_SENDTO, m_pidlSendTo);
    if (SUCCEEDED(hr)) 
    {
        hr = m_sfDesktop->BindToObject(m_pidlSendTo, NULL, IID_IShellFolder, 
            (LPVOID *)&m_sfSendTo);
        if (!SUCCEEDED(hr)) 
        {
            m_sfSendTo = NULL;
        }
    } 
    else 
    {
        m_sfSendTo = NULL;
    }

    m_pShellImageList = CImageList::FromHandle((HIMAGELIST)
        SHGetFileInfo((LPCTSTR)_T("C:\\"), 0, &sfi, sizeof(SHFILEINFO), 
        SHGFI_SYSICONINDEX | SHGFI_SMALLICON));
}

CShCMInitializer::~CShCMInitializer()
{
    m_sfSendTo->Release();
    m_sfDesktop->Release();
}


CShellContextMenu::CShellContextMenu(HWND hWnd, const CString& sAbsPath) : 
    m_hWnd(hWnd), m_sAbsPath(sAbsPath), m_iliFolder(-1), 
    m_bFirstSendToIsMenu(false)
{
    m_lpcm = NULL;
    m_ilSendToMenu.Create(16, 16, ILC_COLOR32 | ILC_MASK, 0, 5);
    m_ilOpenWithMenu.Create(16, 16, ILC_COLOR32 | ILC_MASK, 0, 5);
}

CShellContextMenu::~CShellContextMenu()
{
    if (m_lpcm) m_lpcm->Release();
}

bool CShellContextMenu::IsMenuCommand(int iCmd) const
{
    return (
            (IDM_SENDTOFIRST   <= iCmd  &&  iCmd <= IDM_SENDTOLAST) ||
            (IDM_SHELLCTXFIRST <= iCmd  &&  iCmd <= IDM_SHELLCTXLAST)
           );
}

void CShellContextMenu::InvokeCommand(int iCmd) const
{
    if (!iCmd)
    {
        return;
    }

    if (IDM_SENDTOFIRST <= iCmd  &&  iCmd <= IDM_SENDTOLAST)
    {
        // "Send To..." item

        CPIDL        pidlFile(m_sAbsPath);
        LPDROPTARGET pDT;
        LPDATAOBJECT pDO;
        HRESULT hr;

        hr = pidlFile.GetUIObjectOf(IID_IDataObject, (LPVOID *)&pDO, 
            m_hWnd);
        if (SUCCEEDED(hr))
        {
            CPIDL pidlDrop;
            m_mapPIDLs.Lookup(iCmd, pidlDrop);
            hr = pidlDrop.GetUIObjectOf(IID_IDropTarget, 
                (LPVOID *)&pDT, m_hWnd);

            if (SUCCEEDED(hr))
            {
                // do the drop
                POINTL pt = { 0, 0 };
                DWORD dwEffect = 
                    DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
                hr = pDT->DragEnter(pDO, MK_LBUTTON, pt, &dwEffect);

                if (SUCCEEDED(hr) && dwEffect) 
                {
                    hr = pDT->Drop(pDO, MK_LBUTTON, pt, &dwEffect);
                } 
                else 
                {
                    hr = pDT->DragLeave();
                }

                pDT->Release();
            }

            pidlDrop.m_pidl = NULL;
        }
    }
    else
    {
        // Shell command

        CMINVOKECOMMANDINFO cmi;
        cmi.cbSize       = sizeof(cmi);
        cmi.fMask        = 0;
        cmi.hwnd         = m_hWnd;
        cmi.lpVerb       = MAKEINTRESOURCE(iCmd - IDM_SHELLCTXFIRST);
        cmi.lpParameters = NULL;
        cmi.lpDirectory  = NULL;
        cmi.nShow        = SW_SHOWNORMAL;
        cmi.dwHotKey     = 0;
        cmi.hIcon        = NULL;
        m_lpcm->InvokeCommand(&cmi);
    }
}


// retrieves the shell context menu for a file
void CShellContextMenu::SetMenu(CMenu *pMenu)
{
    HRESULT         hr;
    CPIDL           pidl;

    m_lpcm = NULL;

    if (m_sAbsPath.GetLength() == 0)
    {
        return;
    }

    if (SUCCEEDED(hr = pidl.Set(m_sAbsPath)))
    {
        hr = pidl.GetUIObjectOf(IID_IContextMenu, (LPVOID *)&m_lpcm, m_hWnd);
    }

    if (SUCCEEDED(hr))
    {
        pMenu->DeleteMenu(0, MF_BYPOSITION);
        hr = m_lpcm->QueryContextMenu(*pMenu, 0, IDM_SHELLCTXFIRST, 
            IDM_SHELLCTXLAST, CMF_NODEFAULT | CMF_EXPLORE);

        // try to find the "Send To"/"Open With..." submenus
        CMenu *pSubMenu;
        const int count = pMenu->GetMenuItemCount();
        UINT idmFirstInSubMenu, idm;
        CString str;
        for (int i = 0; i < count; i++)
        {
            pSubMenu = pMenu->GetSubMenu(i);
            if (pSubMenu  &&  pSubMenu->GetMenuItemCount() == 1)
            {
                pSubMenu->GetMenuString(0, str, MF_BYPOSITION);
                idmFirstInSubMenu = pSubMenu->GetMenuItemID(0);

                if (idmFirstInSubMenu >= IDM_OPENWITHID_MIN)
                {
                    // force population of "Open With..." submenu 
                    // (trick courtesy of Philip Oldaker (philip@masmex.com))
                    IContextMenu2 *lpcm2 = NULL;
                    hr = m_lpcm->QueryInterface(IID_IContextMenu2, (LPVOID*)&lpcm2);
                    if (SUCCEEDED(hr))
                    {
                        hr = lpcm2->HandleMenuMsg(WM_INITMENUPOPUP,
                            (WPARAM)pSubMenu->GetSafeHmenu(), 0);
                    }
                    lpcm2->Release();
                }
/*                    IContextMenu2 *lpcm2 = NULL;
                    HRESULT hr = m_lpcm->QueryInterface(IID_IContextMenu2,
                        (LPVOID*)&lpcm2);
                    if (SUCCEEDED(hr))
                    {
                        hr = lpcm2->HandleMenuMsg(WM_INITMENUPOPUP,
                            (WPARAM)pSubMenu->GetSafeHmenu(), 0);
                        lpcm2->Release();
continue;                        
                        // We need the extension to search the registry for 
                        // valid applications.  If there is no extension then 
                        // there's nothing to do
                        CString sExt = GetExt(m_sAbsPath);
                        if (sExt.IsEmpty())
                            continue;
                        // populate "Open With" menu
                        idm = IDM_OPENWITHFIRST;
                        pSubMenu->DestroyMenu();
                        pSubMenu = CMenu::FromHandle(::CreatePopupMenu());
                        ASSERT_VALID(pSubMenu);
                        pMenu->ModifyMenu(i, MF_BYPOSITION | MF_POPUP, 
                        (UINT)pSubMenu->m_hMenu, str);

                        FillOpenWithMenu(pSubMenu, sExt, idm);
                        continue;
                    }
                    else
                    {
                        lpcm2->Release();
                    }
                } */
                else if (idmFirstInSubMenu == IDM_SENDTOID)
                {
                    // populate "Send To" menu
                    idm = IDM_SENDTOFIRST;
                    pSubMenu->DestroyMenu();
                    pSubMenu = CMenu::FromHandle(::CreatePopupMenu());
                    ASSERT_VALID(pSubMenu);
                    pMenu->ModifyMenu(i, MF_BYPOSITION | MF_POPUP, 
                        (UINT)pSubMenu->m_hMenu, str);
                    FillSendToMenu(pSubMenu, stat_data.m_sfSendTo, idm);
                    break;
                }
            }
        }
    }

    return;
}


/////////////////////////////
// Addition: Philip Oldaker
/////////////////////////////
CString CShellContextMenu::GetExt(const CString &sPath)
{
    TCHAR szDir[_MAX_PATH];
    TCHAR szDrive[_MAX_DRIVE];
    TCHAR szFileName[_MAX_FNAME];
    TCHAR szExt[_MAX_EXT];
    szDir[0] = szDrive[0] = szFileName[0] = szExt[0] = 0;
    _tsplitpath(sPath,szDrive,szDir,szFileName,szExt);
    return szExt;
}

// A bunch of registry nonsense to return all relevant details
// but especially the application icon
void CShellContextMenu::GetAppDetails(const CString& sAppName,
    CString& sDisplayName, CString& sCommand, HICON& hIconApp) const
{
    hIconApp = NULL;
    sDisplayName.Empty();
    sCommand.Empty();

    CString sAppKey(szAppKey);
    AddKey(sAppKey,sAppName);
    AddKey(sAppKey, szShellKey);
    HKEY hKey;
    if (RegOpenKeyEx(HKEY_CLASSES_ROOT,sAppKey,0,KEY_READ,&hKey) != ERROR_SUCCESS)
        return;
    BYTE szDisplayName[_MAX_PATH];
    DWORD dwSize=sizeof(szDisplayName);
    DWORD dwType=REG_SZ;
    LONG nRet = RegQueryValueEx(hKey, szDisplayNameEntry, NULL, &dwType,
        szDisplayName,&dwSize);
    if (nRet != ERROR_SUCCESS)
    {
        RegCloseKey(hKey);
        return;
    }
    sDisplayName = szDisplayName;
    TCHAR szSubKey[_MAX_PATH];
    TCHAR szClass[_MAX_PATH];
    DWORD dwSizeSubKey = sizeof(szSubKey)-1;
    DWORD dwSizeClass = sizeof(szClass)-1;
    ZeroMemory(szSubKey,sizeof(szSubKey));
    ZeroMemory(szClass,sizeof(szClass));
    FILETIME ftLastWriteTime;
    HKEY hCmdKey=NULL;
    CString sCmdKey;
    // Search for a key that contains the "command" key as it may not be under "open"
    for(DWORD dwIndex=0;
        RegEnumKeyEx(hKey,dwIndex, 
                      szSubKey, 
                      &dwSizeSubKey,
                      NULL,
                      szClass,
                      &dwSizeClass,
                      &ftLastWriteTime) == ERROR_SUCCESS;dwIndex++)
    {
        sCmdKey = szSubKey;
        AddKey(sCmdKey, szCommandKey);
        if (RegOpenKeyEx(hKey, sCmdKey, 0, KEY_READ, &hCmdKey) == ERROR_SUCCESS)
        {
            break;
        }
        dwSizeSubKey = sizeof(szSubKey)-1;
        dwSizeClass = sizeof(szClass)-1;
    }
    RegCloseKey(hKey);
    hKey = NULL;
    if (hCmdKey == NULL)
        return;
    dwType=REG_SZ | REG_EXPAND_SZ;
    BYTE szCommand[_MAX_PATH];
    dwSize=sizeof(szCommand);
    nRet = RegQueryValueEx(hCmdKey,NULL,NULL,&dwType,szCommand,&dwSize);
    if (nRet != ERROR_SUCCESS)
        return;
    TCHAR szPath[MAX_PATH];
    sCommand = szCommand;
    if (ExpandEnvironmentStrings(sCommand,szPath,sizeof(szPath)))
        sCommand = szPath;
    CString sIconPath(sCommand);
    sIconPath.MakeLower();
    // Only extract icons from exe's at the moment
    int nPos = sIconPath.Find(_T(".exe"));
    if (nPos == -1)
        return;
    sIconPath = sIconPath.Left(nPos+4);
    // Remove auy quotes
    if (sIconPath.Left(1) == '\"')
        sIconPath = sIconPath.Right(sIconPath.GetLength()-1);
    if (sIconPath.Right(1) == '\"')
        sIconPath = sIconPath.Left(sIconPath.GetLength()-1);
    ExtractIconEx(sIconPath, 0, NULL, &hIconApp, 1);        

    RegCloseKey(hCmdKey);
}

// reg helper
void CShellContextMenu::AddKey(CString& sDestKey, const CString& sSrcKey) 
{
    if (sDestKey.Right(1) != '\\')
        sDestKey += '\\';
    sDestKey += sSrcKey;
}
////////////////////////////////////////


////////////////////////////
// Additions: Philip Oldaker
// Scan the registry looking for a OpenWithList key in this format
// Entry MRUList contains the alphabetical order eg. afgrde for each entry
// each of these entries points to the application name which in turn
// has the command and display name
////////////////////////////
void CShellContextMenu::FillOpenWithMenu(CMenu *pMenu, const CString &sExt,
    UINT &idm)
{
	HKEY hKey;
	CString sFileExtKey(szFileExtKey);
	AddKey(sFileExtKey,sExt);
	AddKey(sFileExtKey,szOpenWithListKey);
	if (RegOpenKeyEx(HKEY_CURRENT_USER,sFileExtKey,0,KEY_READ,&hKey) != ERROR_SUCCESS)
		return;
	BYTE szMRUList[_MAX_PATH];
	szMRUList[0] = 0;
	DWORD dwSize=sizeof(szMRUList);
	DWORD dwType=REG_SZ;
	RegQueryValueEx(hKey,szMRUListEntry,NULL,&dwType,szMRUList,&dwSize);
	int nLen = _tcslen((LPCTSTR)szMRUList);
	TCHAR szOpenWithItemEntry[sizeof(TCHAR)*2];
	ZeroMemory(szOpenWithItemEntry,sizeof(szOpenWithItemEntry));
	BYTE szOpenWithItem[_MAX_PATH];
	CString sDisplayName;
	HICON hIconApp;
	CString sCommand;
	CString sMenuText;

	for(int i=0;i < nLen;i++)
	{
		szOpenWithItemEntry[0] = szMRUList[i];
		dwSize = sizeof(szOpenWithItem);
		RegQueryValueEx(hKey,szOpenWithItemEntry,NULL,&dwType,szOpenWithItem,&dwSize);
		GetAppDetails(szOpenWithItem, sDisplayName, sCommand, hIconApp);
		if (!sCommand.IsEmpty())
		{
            pMenu->AppendMenu(MF_STRING, idm, sDisplayName);
            m_ilOpenWithMenu.Add(hIconApp);
//            m_mapPIDLs[idm] = abspidl;
            idm++;
//            pMenu->
//			for(unsigned idm=0;idm < pMenu->GetMenuItemCount();idm++)
if(0)            
			{
				//pMenu->GetMenuString(idm,sMenuText,MF_BYPOSITION);
				//if (sMenuText == sDisplayName)
				{
//					g_CoolMenuManager.ConvertMenuItem(pMenu, idm);
//					CCoolMenuManager::SetItemIcon(*pMenu, hIconApp, idm, TRUE);
	//				break;
				}
			}
		}
	}
	RegCloseKey(hKey);
}

void CShellContextMenu::FillSendToMenu(CMenu *pMenu, LPSHELLFOLDER pSF, 
    UINT &idm)
{
    USES_CONVERSION;
    CPIDL           pidl, abspidl;
    LPENUMIDLIST    peidl;
    HRESULT         hr;
    STRRET          str;
    UINT            idmStart = idm;
    LPSHELLFOLDER   pSubSF;
    SHFILEINFO      sfi;

    if (pSF) 
    {
        int idx_folder = 0; // folder insertion index

        hr = pSF->EnumObjects(m_hWnd, 
            SHCONTF_FOLDERS | SHCONTF_NONFOLDERS, &peidl);

        if (SUCCEEDED(hr))
        {
            while (peidl->Next(1, pidl, NULL) == S_OK  &&
                   idm < IDM_SENDTOLAST) 
            {
                hr = pSF->GetDisplayNameOf(pidl, SHGDN_NORMAL, &str);
                if (SUCCEEDED(hr)) 
                {
                    ULONG ulAttrs = (unsigned)-1;
                    pSF->GetAttributesOf(1, pidl, &ulAttrs);
                    abspidl.MakeAbsPIDLOf(pSF, pidl);
                    SHGetFileInfo((LPCTSTR)abspidl.m_pidl, 0, &sfi, 
                        sizeof(sfi), 
                        SHGFI_PIDL | SHGFI_ICON | SHGFI_SMALLICON);
                    pidl.ExtractCStr(str);
                    if (ulAttrs & SFGAO_FOLDER) // folder?
                    {
                        // create new submenu & recurse
                        HMENU hSubMenu = ::CreateMenu();
                        pMenu->InsertMenu(idx_folder, 
                            MF_POPUP | MF_BYPOSITION | MF_STRING, 
                            (UINT)hSubMenu, str.cStr);
                        m_iliFolder = sfi.iIcon;
                        if (idm == IDM_SENDTOFIRST)
                        {
                            m_bFirstSendToIsMenu = true;
                            idm++;  // needed for IsFolderSubMenu() logic
                        }

                        idx_folder++;
                        hr = pSF->BindToObject(pidl, NULL, 
                            IID_IShellFolder, (LPVOID *)&pSubSF);
                        if (!SUCCEEDED(hr)) pSubSF = NULL;
                        FillSendToMenu(CMenu::FromHandle(hSubMenu), pSubSF, 
                            idm);
                        if (idm == IDM_SENDTOFIRST && m_bFirstSendToIsMenu)
                        {
                            m_bFirstSendToIsMenu = false;
                            idm--;
                        }
                        if (pSubSF) pSubSF->Release();
                        abspidl.Free();
                    }
                    else
                    {
                        pMenu->AppendMenu(MF_STRING, idm, str.cStr);
                        m_ilSendToMenu.Add(sfi.hIcon);
                        m_mapPIDLs[idm] = abspidl;
                        idm++;
                    }
                    abspidl.m_pidl = NULL;
                    pidl.Free();
                }
            }
            peidl->Release();
        }
    }

    // If the menu is still empty (the user has an empty SendTo folder),
    // then add a disabled "(empty)" item so we have at least something
    // to display.
    if (idm == idmStart) 
    {
        pMenu->AppendMenu(
            MF_GRAYED | MF_DISABLED | MF_STRING, IDM_SENDTOLAST, 
            _T("(empty)"));
    }
}

bool CShellContextMenu::GetCommandImage(int iCmd, bool bIsSubMenu,
    CImageList *&pil, int& index)
{
    if (bIsSubMenu)
    {
        if (m_iliFolder >= 0)
        {
            index = m_iliFolder;
            pil = stat_data.m_pShellImageList;
            return true;
        }
        else
        {
            index = -1;
            return false;
        }
    }

    if ((IDM_SENDTOFIRST <= iCmd  &&  iCmd < IDM_SENDTOLAST))
    {
        iCmd -= IDM_SENDTOFIRST;
        if (m_bFirstSendToIsMenu) iCmd--;
        pil = &m_ilSendToMenu;
        index = iCmd;
    }
    else if ((IDM_OPENWITHFIRST <= iCmd  &&  iCmd < IDM_OPENWITHLAST))
    {
        iCmd -= IDM_OPENWITHFIRST;
        pil = &m_ilSendToMenu;
        index = iCmd;
    }
    else
    {
        index = -1;
        return false;
    }

    return true;
}

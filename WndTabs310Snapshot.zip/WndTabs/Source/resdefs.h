/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomonovich, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/


// VC 5 compatibility file

#ifndef TCS_VERTICAL
#define TCS_VERTICAL   0x0080
#endif

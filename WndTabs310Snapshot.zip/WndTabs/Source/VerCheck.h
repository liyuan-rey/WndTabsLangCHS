/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomonovich, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/


#ifndef __VERCHECK_H
#define __VERCHECK_H

enum ConnectionTypes { AutoDetect = 2, RAS = 0, LAN = 1, NoConnection = -1 };

ConnectionTypes AutoDetectINetConnection(LPCSTR pServerName);

CString ReadVersionFile(LPCTSTR szServerName, LPCTSTR szVerFileName);

void CheckForNewVersion(ConnectionTypes connection, HWND hWnd, UINT msg, 
    CString sServerName, CString sVerFileName, bool bWaitForConnection);

// event to tell the reader thread that the program is exiting
extern CEvent chkver_evEndProg;

#endif // __VERCHECK_H

/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomonovich, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/


// ShellContextMenu.h : header file
//

#if !defined(AFX_SHELLCONTEXTMENU_H__24BAC666_2B03_11D3_B9C1_0000861DFCE7__INCLUDED_)
#define AFX_SHELLCONTEXTMENU_H__24BAC666_2B03_11D3_B9C1_0000861DFCE7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define IDM_SHELLCTXFIRST      20000
#define IDM_SHELLCTXLAST       29999
#define IDM_SENDTOFIRST        30000
#define IDM_SENDTOLAST         32000
#define IDM_OPENWITHFIRST      32001
#define IDM_OPENWITHLAST       32767

#include "PIDL.h"

class CShellContextMenu
{
    LPCONTEXTMENU                   m_lpcm;
    CString                         m_sAbsPath;
    HWND                            m_hWnd;
    CImageList                      m_ilSendToMenu;
    CImageList                      m_ilOpenWithMenu;
    int                             m_iliFolder;
    CMap<int, int, CPIDL, CPIDL&>   m_mapPIDLs;
    bool                            m_bFirstSendToIsMenu;

public:    
    CShellContextMenu(HWND m_hWnd, const CString& sAbsPath);
    ~CShellContextMenu();

    bool IsMenuCommand(int iCmd) const;
    void InvokeCommand(int iCmd) const;
    bool GetCommandImage(int iCmd, bool bIsSubmenu, CImageList *&pil, int& index);

    void CShellContextMenu::SetMenu(CMenu *pMenu);

protected:    
    void CShellContextMenu::FillSendToMenu(CMenu *pMenu, 
        LPSHELLFOLDER pSF, UINT& idm);
    void FillOpenWithMenu(CMenu *pMenu,const CString &sExt, UINT& idm); 

	static void AddKey(CString &sDestKey,const CString &sSrcKey);
	static CString GetExt(const CString &sPath);
	void GetAppDetails(const CString &sAppName,CString &sDisplayName,CString &sCommand,HICON &hAppIcon) const;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHELLCONTEXTMENU_H__24BAC666_2B03_11D3_B9C1_0000861DFCE7__INCLUDED_)

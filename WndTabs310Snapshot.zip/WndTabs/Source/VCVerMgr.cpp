/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomonovich, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/

#include "stdafx.h"
#include "WndTabs.h"

#include <initguid.h>
#define WT_INITGUID
#include "VCVerMgr.h"


////////////////////////////////////////////////////////////////////////////
// IID_IDocuments

// {FB7FDAE3-89B8-11CF-9BE8-00A0C90A632C}
//struct __declspec(uuid("{FB7FDAE3-89B8-11CF-9BE8-00A0C90A632C}")) IDocumentsVC;
DEFINE_GUID(IID_IDocuments_VC,
0xFB7FDAE3L,0x89B8,0x11CF,0x9B,0xE8,0x00,0xA0,0xC9,0x0A,0x63,0x2C);

// {9093b40f-e2db-44a0-9caa-ed14c73ffdc5}
//struct __declspec(uuid("{9093b40f-e2db-44a0-9caa-ed14c73ffdc5}")) IDocumentsEVC;
DEFINE_GUID(IID_IDocuments_EVC,
0x9093b40fL,0xe2db,0x44a0,0x9c,0xaa,0xed,0x14,0xc7,0x3f,0xfd,0xc5);


////////////////////////////////////////////////////////////////////////////
// IID_IGenericDocument

// {FB7FDAE1-89B8-11cf-9BE8-00A0C90A632C}
//struct __declspec(uuid("{FB7FDAE1-89B8-11cf-9BE8-00A0C90A632C}")) IGenericDocumentVC;
DEFINE_GUID(IID_IGenericDocument_VC,
0xfb7fdae1, 0x89b8, 0x11cf, 0x9b, 0xe8, 0x0, 0xa0, 0xc9, 0xa, 0x63, 0x2c);

// {c41998bd-f7b1-49bf-874b-b48d6ce99f12}
//struct __declspec(uuid("{c41998bd-f7b1-49bf-874b-b48d6ce99f12}")) IGenericDocumentEVC;
DEFINE_GUID(IID_IGenericDocument_EVC,
0xc41998bd, 0xf7b1, 0x49bf, 0x87, 0x4b, 0xb4, 0x8d, 0x6c, 0xe9, 0x9f, 0x12);


////////////////////////////////////////////////////////////////////////////
// IID_ITextDocument

// {2A6DF201-8240-11CF-AB59-00AA00C091A1}
//struct __declspec(uuid("{2A6DF201-8240-11CF-AB59-00AA00C091A1}")) ITextDocumentVC;
DEFINE_GUID(IID_ITextDocument_VC,
0x2A6DF201L,0x8240,0x11CF,0xAB,0x59,0x00,0xAA,0x00,0xC0,0x91,0xA1);

// {ae0914db-ac28-4834-9361-6dead7a1adad}
//struct __declspec(uuid("{ae0914db-ac28-4834-9361-6dead7a1adad}")) ITextDocumentEVC;
DEFINE_GUID(IID_ITextDocument_EVC,
0xae0914dbL,0xac28,0x4834,0x93,0x61,0x6d,0xea,0xd7,0xa1,0xad,0xad);


VC_Versions g_VCVer = Unknown;
const char *g_pszVCExeName = "Unknown";

static const char *s_pszVCExeNames[] = 
{
    "MSDEV.EXE", "EVC.EXE", "CEPB.EXE"
};


static struct VerInit
{
    VerInit()
    {
        for (int i = 0; i < countof(s_pszVCExeNames); ++i)
        {
            if (GetModuleHandle(s_pszVCExeNames[i]) != 0)
            {
                g_VCVer = VC_Versions(i);
                g_pszVCExeName = s_pszVCExeNames[i];
                break;
            }
        }

        switch (g_VCVer)
        {
            case CEPB:
            case VC:
                memcpy(&IID_IDocuments_Resolved, 
                       &IID_IDocuments_VC, sizeof(GUID));
                memcpy(&IID_IGenericDocument_Resolved, 
                       &IID_IGenericDocument_VC, sizeof(GUID));
                memcpy(&IID_ITextDocument_Resolved, 
                       &IID_ITextDocument_VC, sizeof(GUID));
                break;

            case eVC:
                memcpy(&IID_IDocuments_Resolved, 
                       &IID_IDocuments_EVC, sizeof(GUID));
                memcpy(&IID_IGenericDocument_Resolved, 
                       &IID_IGenericDocument_EVC, sizeof(GUID));
                memcpy(&IID_ITextDocument_Resolved, 
                       &IID_ITextDocument_EVC, sizeof(GUID));
                break;

            default:
                WT_L1_TRACE("Unknown VC Version\n");
                break;
        }
    }
    
} init;

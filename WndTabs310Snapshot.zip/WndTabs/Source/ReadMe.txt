=============================================================================
==                                                                         ==
=  Window Tabs (WndTabs) Addin                     Copyright (c) 1997-2002  =
=  Version 3.10 (Beta 2)                                by Oz Solomonovich  =
==                                                                         ==
=============================================================================


CONTENTS OF THIS FILE:
----------------------
1. Abstract
2. System Requirements
3. What's New
4. Installation
5. Upgrading From an Earlier Version
6. Registration
7. Contact Info


1. Abstract
-----------
"Window Tabs" (WndTabs) is an add-in for Microsoft Visual C++.  It adds a
docking bar of tabs reflecting all of the opened windows in the workspace.  
You can switch between the windows by simply clicking on the tab.  The tabs 
have extensive right-click context menus full of useful functions.
For a tour of the features, see http://www.wndtabs.com/wt/tour


2. System Requirements
----------------------
WndTabs requires Microsoft Visual C++ 5/6, Microsoft eMbedded Visual C++ or
the CE Platform Builder.


3. What's New
-------------
v3.05 is a mantinance release, combining all the bug fixes from the previous
3.0x version, and two new features:
- Added Close button to tabs on the advanced tab control.
- Tabs without a group can now appear with a mini-toolbar, for consistent 
  tab appearance.

v3.0 was is a major update to WndTabs.

Enhancements:
- Totally revamped UI! 
- UI now supports totally customizable menus/toolbar and keyboard shortcuts. 
  [WndTabsExt]
- New WndTabs SDK adds support for addons.  Addons can: 
    o Add new commands to WndTabs.  For example, the CvsIn addin 
      (www.cvsin.org) adds CVS related version control commands to the tabs.
    o Alter the tabs themselves!  For example, the WndTabs SDK sample addon 
      can 
      draw a red border around icons of read-only files.  CvsIn will add CVS 
      status icons to the tabs. [WndTabsExt]
- Full support for eMbedded Visual C++ and CE Platform Builder! 
- More control over tab ordering! 
    o Alphabetic tab ordering. 
    o Tab number persistence (WndTabs can save your tab numbers when you 
      close the project file). 
- More Trimming Options: File Prefix/Suffix trimming (can remove selected 
  prefixes and suffixes from tab text) 
- New Feature: Auto-Row Count (tabs automatically take as many rows as needed 
  to fit all). 
- New Feature: Separate window-count limitations when debugging. 
- New Feature: Limit the number of tab groups. 
- New Feature: Automatically close windows opened during debugging (using a 
  custom filter). 
- New Feature: Disable splash screen. [WndTabsExt]
- New Command: Open file's containing folder. 
- New Commands: Go to group next/Go to group previous (for cycling through a 
  tab group). [WndTabsExt]
- Added: Auto-open alternate file feature for automatically opening file 
  groups. 
- Added: Limited tab font selection. 

For a complete history of program changes, see "Version History" in the 
online help.


4. Installation
---------------
The WndTabs installation comes in the form of a Microsoft Installer database 
(MSI file).  To install, simply double-click on the MSI file.  
Due to the design of the Microsoft Installer, you might encounter some
difficulty while trying to install WndTabs.  In these cases, please consult
the only FAQ page for help:
    http://www.wndtabs.com/wt/faq.asp


5. Upgrading From an Earlier Version
------------------------------------

  5.1 Upgrading from v3.0x
  ------------------------
  If you are installing version 3.05 over version 3.02, 3.01 or 3.00, you must 
  use the upgrade patch program.  If you are having problems applying the patch, 
  please refer to the online FAQ.

  5.2 Upgrading from v2.50
  ------------------------
  The WndTabs 3.0 installer will automatically upgrade your 2.50 
  installation, and will also import your settings.

  5.3 Upgrading from older versions
  ---------------------------------
  Versions of WndTabs earlier than v2.50 are not supported by the v3.0 
  installer.  If you are currently running an earlier version of WndTabs,
  you should remove it manually before starting the installation.


6. Registration
---------------
The core WndTabs product is freeware.  The extension module (WndTabsExt) 
shipped with WndTabs is not.  You may register WndTabsExt for the price of 
$10.  Complete details on pricing and how to order are in the help file and
on the WndTabs web site.

Time limited, trial registration codes are also available for those who want
to try out WndTabsExt before buying.  (Codes last between 3-4 weeks).  You 
may apply for a free code at the following address:
http://www.wndtabs.com/register/trialreq.asp
You can also download a trial code automatically through the WndTabs 
Options|Register dialog.

Please note that trial codes are limited to *one per person*.


7. Contact Info
---------------
If you have any questions, comments or suggestions, feel free to contact me:

    web:    http://www.wndtabs.com
    e-mail: support@wndtabs.com


Enjoy WndTabs!

/***************************************************************************/
/* NOTE:                                                                   */
/* This document is copyright (c) by Oz Solomonovich, and is bound by the  */
/* MIT open source license (www.opensource.org/licenses/mit-license.html). */
/* See License.txt for more information.                                   */
/***************************************************************************/


#include "stdafx.h"
#include <process.h>
#include <afxinet.h>
#include <afxsock.h>

#include "VerCheck.h"
#include "Config.h"
#include "Utils.h"

#undef WINVER
#define WINVER 0x0410
#include <ras.h>

static HWND s_hWnd;
static UINT s_uMsg;
static CString *s_pServerName;
static CString *s_pVerFileName;  
static CString s_sVerFromNet;
static ConnectionTypes s_conType;

CEvent chkver_evEndProg;

// the following routine was written by Jeroen-Bart Engelen 
// (j.engelen@planetinternet.nl) and was taken from his article posting on
// CodeGuru (http://www.codeguru.com/network/RasDetect.shtml)
static int RasDetect(void)
{
    HKEY registry = NULL;
    DWORD result;
    OSVERSIONINFO version;
    /* FIXME: GetLastError zelf implementeren */
    char regkey[70];
    
    /* First we have to find out which OS we are running on */
    version.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    /* If we get and error, we can't continue. */
    if(!GetVersionEx(&version)) return -666;
    
    /* Then we set the registry key we want to look at */
    /* according to the OS we detected. */
    
    /* NOTE: WinME uses a registry layout similair to WinNT!! */
    if (version.dwPlatformId 
        == VER_PLATFORM_WIN32_WINDOWS && version.dwMinorVersion != 90) 
        strcpy(regkey, "system\\currentcontrolset\\services"
        "\\remoteaccess\\networkprovider");
    else 
        strcpy(regkey,"system\\currentcontrolset\\services\\remoteaccess");
    
    /* We then try to open the registry key */
    if ((result = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        regkey, 0, 
        STANDARD_RIGHTS_READ | KEY_QUERY_VALUE | KEY_ENUMERATE_SUB_KEYS 
        | KEY_NOTIFY | READ_CONTROL,
        &registry)) 
        != ERROR_SUCCESS)
    {
        if(result == ERROR_FILE_NOT_FOUND)
        { 
            RegCloseKey(registry);
            return 0; // No RAS found
        }
        else
        {
            RegCloseKey(registry);
            return -1; // Some other error
        }
    } 
    
    RegCloseKey(registry);

    // Modification by O.S.: Try to load dll anyway
    HMODULE dllRAS = ::LoadLibraryA("rasapi32.dll");
    if (dllRAS)
    {
        ::FreeLibrary(dllRAS);
        return 1;
    }

    return 0; 
}


ConnectionTypes AutoDetectINetConnection(LPCSTR pServerName)
{
    // A catch: The first attempt by the auto-detector is a LAN connection
    // (which must be ruled out before a RAS connected is attempted).  
    // Unfortunately, under certain conditions, Win 9x systems might cause
    // the auto-dialer dialog to appear as soon as any socket operation is
    // attempted on RAS-enabled machines.  This is very undesirable.  We
    // will therefore deduct that machines with their auto-dialer enabled
    // are RAS machines.
    OSVERSIONINFO osvi;
    osvi.dwOSVersionInfoSize = sizeof(osvi);
    GetVersionEx(&osvi);
    if (osvi.dwPlatformId != VER_PLATFORM_WIN32_NT)
    {
        CRegKey key;
        char    buf[256];
        DWORD   cb, type;        
        if (key.Open(HKEY_CURRENT_CONFIG, 
            "Software\\Microsoft\\windows\\CurrentVersion\\Internet Settings") == ERROR_SUCCESS)
        {
            RegQueryValueEx(key.m_hKey, "EnableAutodial", 0, &type,
                (LPBYTE)&buf, &cb);
            if (type == REG_BINARY  &&  cb == 4) // the only case I know
            {
                if (buf[0] == 1)  // enabled?
                {
                    // force RAS mode
                    goto is_RAS;
                }
            }
        }
    }

    // first, check for a possible direct connection to the i-net
    HOSTENT *phe;
    phe = gethostbyname(pServerName);  // this can take a long time....
    if (phe)
    {
        // ok, we have a DNS.  now let's see if we're really connected to
        // the net
        SOCKET s = socket(PF_INET, SOCK_STREAM, 0);
        if (s != INVALID_SOCKET)
        {
            SOCKADDR_IN sin;
            int err;

            sin.sin_family = AF_INET; 
            sin.sin_addr.s_addr = *(unsigned long *)((phe->h_addr_list)[0]); 
            sin.sin_port = htons(INTERNET_DEFAULT_HTTP_PORT);  
            err = connect (s, (LPSOCKADDR) &sin, sizeof (sin));
            closesocket(s);

            if (err == 0)
            {
                // ok, we're connected...
                return LAN;
            }
        }
    }

    // if it's not LAN then...
is_RAS:    
    if (RasDetect())
    {
        return RAS;
    }
    else
    {
        return NoConnection;
    }
}


CString ReadVersionFile(LPCTSTR szServerName, LPCTSTR szVerFileName)
{
    CInternetSession  inets(_T("VersionChecker/" + g_cVersion));
    CHttpConnection  *pcHTTP = NULL;
    CHttpFile        *pHTTPFile = NULL;
    CString           sVerFromHTML;
    
    sVerFromHTML.Empty();
    TRY
    {
        pcHTTP = inets.GetHttpConnection(szServerName);
        pHTTPFile = pcHTTP->OpenRequest("GET", szVerFileName, NULL, 1, NULL,
            NULL, INTERNET_FLAG_DONT_CACHE | INTERNET_FLAG_RELOAD);
        if (pHTTPFile  &&  pHTTPFile->SendRequest() == TRUE)
        {
            pHTTPFile->ReadString(sVerFromHTML);
            if (sVerFromHTML.Left(8) == _T("Version "))
                sVerFromHTML = sVerFromHTML.Mid(9);
            else
                sVerFromHTML.Empty();
        }
        if (pHTTPFile) pHTTPFile->Close();
        pcHTTP->Close();
    }
    CATCH_ALL(e)
    {
        sVerFromHTML.Empty();
    }
    END_CATCH_ALL;

    if (pHTTPFile) delete pHTTPFile;
    if (pcHTTP)    delete pcHTTP;

    return sVerFromHTML;
}

static bool CheckAddress(DWORD addr)
{
    SOCKADDR_IN sin;
    int         err = 0;
    SOCKET      s = socket(PF_INET, SOCK_STREAM, 0);

    if (s == INVALID_SOCKET)
        return false;

    // disable Nagle algorithm
    BOOL b = TRUE;
    setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char *)&b, sizeof(b));

    sin.sin_family = AF_INET; 
    sin.sin_addr.s_addr = addr; 
    sin.sin_port = htons(INTERNET_DEFAULT_HTTP_PORT);  
    err = connect (s, (LPSOCKADDR) &sin, sizeof (sin));
    closesocket(s);

    return (err == 0);
}

// this thread is responsible for calling ReadVersionFile if and only if it
// can verify that the user is connected to the internet
// 1. looks for a direct connection (over a LAN)
// 2. checks for an active RAS (dialup) connection
// 3. optionally waits for a modem connection
// the user should never see any indication that this is going on, i.e. the
// nagging auto-dial dialog should never show.
static void VersionReaderThread(LPVOID pContext)
{
    RASCONN     rc;
    BOOL        bWaitForConnection = (BOOL)pContext;
    DWORD       sizein, sizeout;
    char        sVerFileName[128], sServerName[128];
    HMODULE     dllRAS = NULL;
    
    // deleteing the strings now will avoid pesky "memory leak" 
    // diagnostic messages in cases where the thread aborts abruptly
    strcpy(sVerFileName, *s_pVerFileName);
    strcpy(sServerName,  *s_pServerName);
    delete s_pVerFileName;
    delete s_pServerName;

    const ConnectionTypes ConTypeToUse = 
        (s_conType == AutoDetect)? 
            AutoDetectINetConnection(sServerName) : s_conType;

    if (ConTypeToUse == NoConnection)
    {
        return;
    }

    // first, check for a possible direct connection to the i-net
    if (ConTypeToUse == LAN)
    {
        s_sVerFromNet = ReadVersionFile(sServerName, sVerFileName);
    }

    if (s_sVerFromNet.IsEmpty() /* still not retrieved */  &&  
        (ConTypeToUse == RAS  ||  s_conType == AutoDetect)  &&
        RasDetect())
    {
        // we don't have a direct i-net connection, so try RAS
        dllRAS = ::LoadLibraryA("rasapi32.dll");
        typedef DWORD (APIENTRY fnRasEnumConnections)( LPRASCONNA, LPDWORD, LPDWORD );
        typedef DWORD (APIENTRY fnRasConnectionNotification)( HRASCONN, HANDLE, DWORD );
        fnRasEnumConnections *pfnRasEnumConnections = NULL;
        fnRasConnectionNotification *pfnRasConnectionNotification = NULL;

        sizeout = 1;

        if (dllRAS)
        {
            pfnRasEnumConnections = (fnRasEnumConnections *)
                ::GetProcAddress(dllRAS, "RasEnumConnectionsA");
            pfnRasConnectionNotification = (fnRasConnectionNotification *)
                ::GetProcAddress(dllRAS, "RasConnectionNotificationA");
        }

        if (pfnRasEnumConnections  &&  pfnRasConnectionNotification)
        {
            sizein = rc.dwSize = sizeof(rc);
            (*pfnRasEnumConnections)(&rc, &sizein, &sizeout);
        }

        if (sizeout == 0) // not connected
        {
            if (bWaitForConnection)
            {
                CEvent ev;
                HANDLE evs[] = { ev.m_hObject, chkver_evEndProg.m_hObject };

                (*pfnRasConnectionNotification)(
                    (HRASCONN)INVALID_HANDLE_VALUE, ev, RASCN_Connection);
                if (WaitForMultipleObjects(2, (const HANDLE *)&evs, FALSE, 
                    INFINITE) != WAIT_OBJECT_0)
                {
                    goto byebye;
                }
            }
            else
            {
                goto byebye;
            }
        }

        s_sVerFromNet = ReadVersionFile(sServerName, sVerFileName);
    }

    if (!s_sVerFromNet.IsEmpty())
    {
        ::PostMessage(s_hWnd, s_uMsg, 0, (LPARAM)&s_sVerFromNet);
    }

byebye:    
    if (dllRAS)
        ::FreeLibrary(dllRAS);

    return;
}

void CheckForNewVersion(ConnectionTypes connection, HWND hWnd, UINT msg, 
    CString sServerName, CString sVerFileName, bool bWaitForConnection)
{
    s_hWnd = hWnd;
    s_uMsg = msg;
    s_pServerName  = new CString(sServerName);
    s_pVerFileName = new CString(sVerFileName);
    s_conType = connection;

    _beginthread(VersionReaderThread, 0, (PVOID)bWaitForConnection);
}

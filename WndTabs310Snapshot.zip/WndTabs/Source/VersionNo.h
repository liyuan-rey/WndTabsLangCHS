// see Microsoft KB article Q237870 

#define FILEVER        3,10,1,2
#define PRODUCTVER     FILEVER
#define STRFILEVER     "3.10 Beta 2\0"
#define STRPRODUCTVER  STRFILEVER 
